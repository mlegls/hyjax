# Hyjax

Hyjax is [Hy](https://github.com/hylang/hy) bindings for [JAX](https://github.com/google/jax).

The goal is to let fully JIT-compiled JAX code to be written in idiomatic Lisp.
